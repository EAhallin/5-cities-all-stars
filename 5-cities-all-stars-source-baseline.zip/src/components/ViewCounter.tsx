import { useEffect, useState } from 'react';
import { Eye } from 'lucide-react';
import { supabase } from '@/lib/supabase';

export function ViewCounter() {
  const [count, setCount] = useState<number | null>(null);

  useEffect(() => {
    supabase
      .rpc('increment_page_views')
      .then(({ data, error }) => {
        if (!error && typeof data === 'number') {
          setCount(data);
        }
      });
  }, []);

  if (count === null) {
    return (
      <div className="view-counter" aria-label="Loading view count">
        <Eye size={14} />
        <span>—</span>
      </div>
    );
  }

  return (
    <div className="view-counter" aria-label={`This site has been viewed ${count.toLocaleString()} times`}>
      <Eye size={14} />
      <span>{count.toLocaleString()} VIEWS</span>
    </div>
  );
}
