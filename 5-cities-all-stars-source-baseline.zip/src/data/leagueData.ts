export type Ranking = {
  rank: number;
  owner: string;
  grade: string;
  record: string;
  tier: string;
  core: string[];
  analysis: string;
  roast: string;
};

export const rankings: Ranking[] = [
  { rank: 1, owner: 'Cody', grade: 'A', record: '10-4', tier: 'Title favorite', core: ['JSN', 'Chase Brown', 'Chris Olave', 'Colston Loveland', 'Jameson Williams', 'Courtland Sutton', 'Trevor Lawrence'], analysis: 'Best combination of keeper value, usable depth and not doing anything catastrophically stupid. JSN and Chase Brown for $40 gave him a ridiculous foundation. Lawrence for $1 and Jameson for $10 were two of the better buys in the room. There is no glaring weakness here.', roast: 'Cody drafted like someone who had the radical idea of being sober, awake and aware that a fantasy draft was occurring.' },
  { rank: 2, owner: 'Brandon', grade: 'A−', record: '9-5', tier: 'Title contender', core: ['Ja’Marr Chase', 'Jahmyr Gibbs', 'Joe Burrow', 'Tetairoa McMillan', 'Travis Kelce'], analysis: 'Chase plus Gibbs gives Brandon perhaps the league’s nastiest superstar foundation. Burrow for $12 was excellent. The concern is the RB2 and flex depth underneath the stars.', roast: 'Apparently returning from a multi-year commissioner-exempt stint is excellent fantasy preparation. Brandon came back ready to roll.' },
  { rank: 3, owner: 'Boo', grade: 'A−', record: '9-5', tier: 'Dangerous as hell', core: ['Lamar Jackson', 'Derrick Henry', 'Kyren Williams', 'Travis Etienne', 'Justin Jefferson', 'George Pickens', 'DK Metcalf'], analysis: 'Possibly the most terrifying healthy-week starting lineup in the league. Henry and Kyren can hammer the rushing bonuses while Jefferson, Pickens and Metcalf chase receiving bonuses. Depth becomes thin quickly if injuries hit.', roast: 'Absolutely horrifying on Sunday. Approximately six healthy hamstrings away from bankruptcy.' },
  { rank: 4, owner: 'Chad', grade: 'B+', record: '8-6', tier: 'Contender', core: ['CeeDee Lamb', 'A.J. Brown', 'Brock Bowers', 'Dak Prescott', 'Dalton Kincaid', 'Quinshon Judkins'], analysis: 'The receiving foundation is excellent. Lamb, A.J. Brown and Bowers creates weekly ceiling. Dak for $8 and Kincaid for $2 were smart. Running back is the obvious vulnerability.', roast: 'FUCK YOU COMMISH.' },
  { rank: 5, owner: 'Eric', grade: 'B+', record: '8-6', tier: 'Contender — top 3 upside', core: ['Justin Herbert $5', 'De’Von Achane', 'Omarion Hampton', 'Drake London $36', 'Malik Nabers $25', 'Garrett Wilson $25', 'Terry McLaurin $16', 'Chris Godwin $9'], analysis: 'Receiver-heavy strategy executed deliberately. Achane and Hampton supplied the RB foundation, then Eric hammered WR while refusing to spend at QB or TE. McLaurin for $16 and Herbert for $5 were excellent purchases.', roast: 'Spent basically everything on receivers and then found his tight ends in the parking lot.' },
  { rank: 6, owner: 'Alex', grade: 'B+', record: '8-6', tier: 'Dangerous', core: ['Drake Maye', 'Ashton Jeanty', 'Zay Flowers', 'Rome Odunze', 'Emeka Egbuka', 'Mike Evans', 'Tucker Kraft'], analysis: 'Maye for $11, Evans for $12 and Kraft for $8 were strong. Flowers, Odunze and Egbuka gives him legitimate upside. Jeanty for $53 and Egbuka for $29 mean several breakouts are already priced in.', roast: 'After finishing last two years in a row, Alex was forced to draft wearing the Dick the Halls punishment outfit. Humiliation may finally be working.' },
  { rank: 7, owner: 'Jason', grade: 'B+', record: '7-7', tier: 'Playoff caliber', core: ['Amon-Ra St. Brown', 'James Cook', 'Bucky Irving', 'Rhamondre Stevenson', 'Rico Dowdle', 'Caleb Williams', 'Jaxson Dart', 'Luther Burden'], analysis: 'Balanced roster and one of the deeper RB rooms. Amon-Ra and Cook are excellent anchors. Burden for $25, Irving for $22 and Stevenson for $18 left the receiving depth below Amon-Ra less convincing.', roast: 'Built enough running back inventory to open a dealership.' },
  { rank: 8, owner: 'Jonny', grade: 'B', record: '7-7', tier: 'Dark horse', core: ['Bijan Robinson', 'Saquon Barkley', 'Rashee Rice', 'DeVonta Smith', 'Jaylen Warren', 'Jayden Daniels', 'Jakobi Meyers'], analysis: 'Bijan plus Saquon is one hell of an introduction to the league. Rice and DeVonta gives him legitimate receiving production and Meyers for $2 was smart. Bottom-of-roster depth is the concern.', roast: 'New guy showed up, drafted Bijan and Saquon, avoided humiliating himself and left. Suspiciously competent behavior.' },
  { rank: 9, owner: 'Donovan', grade: 'B', record: '6-8', tier: 'Needs things to break right', core: ['Jonathan Taylor', 'Nico Collins', 'Trey McBride', 'Breece Hall', 'Michael Pittman', 'Jared Goff', 'KC Concepcion'], analysis: 'Taylor, Nico and McBride is a strong top three. Pittman for $5 and Goff for $2 were strong value. Hall for $34 and some questionable receiver depth limit the roster.', roast: 'Enough stars to ruin somebody’s Sunday. Enough questionable depth to ruin his own.' },
  { rank: 10, owner: 'JP', grade: 'B−', record: '6-8', tier: 'High variance', core: ['Puka Nacua', 'Kenneth Walker', 'Jaylen Waddle', 'David Montgomery', 'Sam LaPorta', 'Matthew Stafford'], analysis: 'Puka, Walker and Waddle is a legitimate foundation. LaPorta for $6 and Stafford for $6 were reasonable. Montgomery at $33 was one of the biggest questionable purchases of the draft.', roast: 'Approximately halfway through the draft JP entered a different dimension.' },
  { rank: 11, owner: 'Matt', grade: 'C+', record: '5-9', tier: 'CMC needs miracles', core: ['Christian McCaffrey', 'Ladd McConkey', 'Tee Higgins', 'Jalen Hurts', 'D’Andre Swift', 'Harold Fannin'], analysis: 'There are legitimate stars here, but the roster underneath them is chaotic. Swift for $25 and several mid-tier receiver purchases reduced flexibility. Four tight ends is a lot.', roast: 'This roster looks exactly like what happens when morning golf starts drinking several hours before a 6 PM auction.' },
  { rank: 12, owner: 'Poojie', grade: 'C', record: '4-10', tier: 'The Poojie Zone', core: ['Josh Allen', 'Cam Skattebo', 'Jeremiyah Love', 'Marvin Harrison Jr.', 'Jadarian Price', 'DJ Moore'], analysis: 'Allen for $21 was good. Beyond that, a huge amount of the roster requires young players to outperform what Poojie paid. There is legitimate upside if several hit.', roast: 'Poojie could begin October 5-1 and somehow finish November owning three backup quarterbacks and a receiver who retired in 2024.' },
];

export const tiers = [
  { label: 'Tier 1', title: 'Someone needs to deal with these assholes', owners: 'Cody · Brandon · Boo', tone: 'hot' },
  { label: 'Tier 2', title: 'Legitimately can win the league', owners: 'Chad · Eric · Alex · Jason', tone: 'warm' },
  { label: 'Tier 3', title: '8-6 or 5-9 — who the hell knows', owners: 'Jonny · Donovan', tone: 'cool' },
  { label: 'Tier 4', title: 'Chemical assistance was involved', owners: 'JP · Matt', tone: 'dark' },
  { label: 'Tier 5', title: 'The Poojie Zone', owners: 'Poojie', tone: 'poojie' },
];

export const standings = rankings.map(({ rank, owner, record }) => ({ rank, owner, record, note: ['Favorite', 'Star power', 'Sunday nightmare', 'The regime', 'Hampton Inn', 'Punishment tour', 'RB warehouse', 'New guy', 'High ceiling', 'Cosmic variance', 'K. Robinson', 'Poojie Zone'][rank - 1] }));

export const steals = [
  ['Trevor Lawrence', '$1', 'Cody'], ['Drake Maye', '$11', 'Alex'], ['Jameson Williams', '$10', 'Cody'], ['Justin Herbert', '$5', 'Eric'], ['Terry McLaurin', '$16', 'Eric'], ['DK Metcalf', '$9', 'Boo'], ['Michael Pittman', '$5', 'Donovan'], ['Jakobi Meyers', '$2', 'Jonny'],
];

export const crimes = [
  ['David Montgomery', '$33', 'JP'], ['Jeremiyah Love', '$36', 'Poojie'], ['Ashton Jeanty', '$53', 'Alex'], ['Luther Burden', '$25', 'Jason'], ['Emeka Egbuka', '$29', 'Alex'], ['Marvin Harrison Jr.', '$23', 'Poojie'], ['Jadarian Price', '$20', 'Poojie'], ['Breece Hall', '$34', 'Donovan'],
];

export const rules = [
  { title: 'Passing', kicker: 'The arm tax', items: ['1 point per 25 yards', '+6 at 300 passing yards', '+6 additional at 500 yards', 'Passing TD: 6', 'Interception: −2'], callout: '300 YARDS MATTERS', body: 'A 300-yard passing game is worth an extra touchdown in this league.' },
  { title: 'Rushing', kicker: 'Volume gets paid', items: ['0.15 points per carry', '1 point per 10 yards', '+6 at 100 rushing yards', '+6 additional at 200 yards', 'Rushing TD: 6'], callout: 'VOLUME GETS PAID', body: 'A 20-carry game generates 3 fantasy points before rushing yardage is even counted.' },
  { title: 'Receiving', kicker: 'Full PPR chaos', items: ['1 point per reception', '1 point per 10 yards', '+6 at 100 receiving yards', '+6 additional at 200 yards', 'Receiving TD: 6'], callout: '100-YARD GAMES ARE NUCLEAR', body: 'Eight catches, 105 yards and a touchdown scores 30.5 points. That is why explosive WRs command huge premiums.' },
];
