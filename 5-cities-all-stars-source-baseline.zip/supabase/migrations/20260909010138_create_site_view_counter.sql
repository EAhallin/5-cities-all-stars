/*
# Site View Counter

1. New Tables
- `site_stats` — single-row table holding the cumulative page view count.
  - `id` (int, primary key, always 1) — ensures only one row exists.
  - `views` (bigint, not null, default 0) — the running view counter.
  - `updated_at` (timestamptz) — last increment timestamp.

2. New Functions
- `increment_page_views()` — SECURITY DEFINER function that atomically
  increments the `views` column by 1 and returns the new total. Uses
  `RETURNING` so the caller gets the updated value in a single round-trip,
  avoiding race conditions when multiple visitors load the page simultaneously.
  Marked SECURITY DEFINER so it can update the row even though the anon role
  only has SELECT access (no direct INSERT/UPDATE needed from the client).

3. Security
- RLS enabled on `site_stats`.
- SELECT policy allows `anon, authenticated` to read the current count
  (the counter value is intentionally public — it's displayed on the site).
- No INSERT/UPDATE/DELETE policies: all mutations go through the
  `increment_page_views()` RPC function, which runs as the table owner.
- `increment_page_views()` is executable by `anon, authenticated`.

4. Notes
- The single row is seeded with `id = 1, views = 0` on first run.
- Idempotent: safe to re-run; uses `IF NOT EXISTS` guards and `DROP FUNCTION IF EXISTS`.
*/

CREATE TABLE IF NOT EXISTS site_stats (
  id integer PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  views bigint NOT NULL DEFAULT 0,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE site_stats ENABLE ROW LEVEL SECURITY;

-- Seed the single row if it doesn't exist
INSERT INTO site_stats (id, views)
VALUES (1, 0)
ON CONFLICT (id) DO NOTHING;

-- Public read: anyone can see the current view count
DROP POLICY IF EXISTS "anon_read_site_stats" ON site_stats;
CREATE POLICY "anon_read_site_stats"
ON site_stats FOR SELECT
TO anon, authenticated
USING (true);

-- Atomic increment function (SECURITY DEFINER so anon can call it
-- without needing direct UPDATE privileges)
CREATE OR REPLACE FUNCTION increment_page_views()
RETURNS bigint
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_count bigint;
BEGIN
  UPDATE site_stats
  SET views = views + 1, updated_at = now()
  WHERE id = 1
  RETURNING views INTO new_count;

  IF new_count IS NULL THEN
    -- Row doesn't exist yet (shouldn't happen due to seed, but guard anyway)
    INSERT INTO site_stats (id, views) VALUES (1, 1)
    ON CONFLICT (id) DO UPDATE SET views = site_stats.views + 1, updated_at = now()
    RETURNING views INTO new_count;
  END IF;

  RETURN new_count;
END;
$$;

-- Grant execute to anon and authenticated
GRANT EXECUTE ON FUNCTION increment_page_views() TO anon, authenticated;
